<?php
/**
 * Plugin Name: Coinvera Crypto Gateway
 * Description: Paiement par carte via Coinvera, avec confirmation verifiee cote serveur.
 * Version: 0.1.0
 * Requires Plugins: woocommerce
 * Text Domain: coinvera
 */
if (!defined('ABSPATH')) exit;
define('CV_VERSION', '0.1.0');
define('CV_SLUG', 'coinvera-crypto-gateway/coinvera-crypto-gateway.php');

add_filter('cron_schedules', function ($s) { $s['cv_5min'] = ['interval' => 300, 'display' => 'Toutes les 5 minutes']; return $s; });
register_activation_hook(__FILE__, function () { if (!wp_next_scheduled('cv_check_orders')) wp_schedule_event(time() + 60, 'cv_5min', 'cv_check_orders'); });
register_deactivation_hook(__FILE__, function () { wp_clear_scheduled_hook('cv_check_orders'); });

add_action('plugins_loaded', function () {
  if (!class_exists('WC_Payment_Gateway')) return;

  class WC_Gateway_Coinvera extends WC_Payment_Gateway {
    public function __construct() {
      $this->id = 'coinvera'; $this->method_title = 'Coinvera'; $this->method_description = 'Paiement par carte via Coinvera.'; $this->has_fields = false;
      $this->init_form_fields(); $this->init_settings();
      $this->title = $this->get_option('title'); $this->description = $this->get_option('description'); $this->enabled = $this->get_option('enabled');
      add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }
    public function init_form_fields() {
      $this->form_fields = [
        'enabled' => ['title' => 'Activer', 'type' => 'checkbox', 'label' => 'Activer Coinvera', 'default' => 'no'],
        'title' => ['title' => 'Titre', 'type' => 'text', 'default' => 'Carte bancaire'],
        'description' => ['title' => 'Description', 'type' => 'text', 'default' => 'Paiement sécurisé par carte Visa ou Mastercard.'],
        'api_base' => ['title' => 'URL de l’API', 'type' => 'text', 'default' => 'https://coinvera.com'],
        'public_key' => ['title' => 'Clé API publique', 'type' => 'text'],
        'secret' => ['title' => 'Clé API secrète', 'type' => 'password'],
        'license_key' => ['title' => 'Clé de licence', 'type' => 'text', 'description' => 'Obtenue dans votre tableau de bord Coinvera > WooCommerce.'],
      ];
    }
    public function process_admin_options() {
      $ok = parent::process_admin_options();
      $r = $this->license('activate');
      if (is_wp_error($r) || empty($r['valid'])) WC_Admin_Settings::add_error('Licence Coinvera non valide ou limite d’activations atteinte.');
      else WC_Admin_Settings::add_message('Licence Coinvera activée pour ce site.');
      delete_transient('cv_license_ok');
      return $ok;
    }
    public function license($action) {
      $r = wp_remote_post(rtrim($this->get_option('api_base'), '/') . '/api/license/' . $action, ['timeout' => 15, 'headers' => ['Content-Type' => 'application/json'],
        'body' => wp_json_encode(['licenseKey' => $this->get_option('license_key'), 'siteUrl' => home_url()])]);
      if (is_wp_error($r)) return $r;
      return json_decode(wp_remote_retrieve_body($r), true);
    }
    private function license_ok() {
      $v = get_transient('cv_license_ok');
      if ($v === false) { $r = $this->license('check'); $v = (!is_wp_error($r) && !empty($r['valid'])) ? 'yes' : 'no'; set_transient('cv_license_ok', $v, 12 * HOUR_IN_SECONDS); }
      return $v === 'yes';
    }
    public function is_available() { return parent::is_available() && $this->license_ok(); }
    // Requete signee : HMAC-SHA256(secret, "ts.nonce.METHOD.path.sha256(corps)")
    public function call($method, $path, $body = null, $extra = []) {
      $raw = $body === null ? '' : wp_json_encode($body); $ts = (string) round(microtime(true) * 1000); $nonce = bin2hex(random_bytes(12));
      $sig = hash_hmac('sha256', "$ts.$nonce.$method.$path." . hash('sha256', $raw), $this->get_option('secret'));
      $args = ['method' => $method, 'timeout' => 20, 'headers' => array_merge(['Content-Type' => 'application/json', 'X-Api-Key' => $this->get_option('public_key'), 'X-Timestamp' => $ts, 'X-Nonce' => $nonce, 'X-Signature' => $sig], $extra)];
      if ($raw !== '') $args['body'] = $raw;
      $r = wp_remote_request(rtrim($this->get_option('api_base'), '/') . $path, $args);
      if (is_wp_error($r)) return $r;
      return ['code' => wp_remote_retrieve_response_code($r), 'data' => json_decode(wp_remote_retrieve_body($r), true)];
    }
    public function process_payment($order_id) {
      $order = wc_get_order($order_id);
      if ($order->get_currency() !== 'USD') { wc_add_notice('Ce moyen de paiement accepte uniquement les commandes en USD.', 'error'); return ['result' => 'failure']; }
      $res = $this->call('POST', '/api/v1/payments', ['amount' => (float) $order->get_total(), 'title' => 'Commande #' . $order->get_order_number(), 'customerEmail' => $order->get_billing_email(), 'orderRef' => (string) $order_id], ['Idempotency-Key' => 'order-' . $order_id]);
      if (is_wp_error($res) || !in_array($res['code'], [200, 201], true) || empty($res['data']['checkoutUrl'])) {
        $order->add_order_note('Coinvera : création du paiement impossible' . (is_wp_error($res) ? '' : ' (' . ($res['data']['error'] ?? $res['code']) . ')'));
        wc_add_notice('Le paiement est momentanément indisponible. Réessayez plus tard.', 'error'); return ['result' => 'failure'];
      }
      $order->update_meta_data('_cv_payment_id', $res['data']['id']); $order->update_meta_data('_cv_mode', $res['data']['mode']);
      $order->update_status('pending', 'En attente du paiement Coinvera.'); $order->save();
      return ['result' => 'success', 'redirect' => $res['data']['checkoutUrl']];
    }
    // Ne passe JAMAIS la commande en "payee" sur un simple retour client : on interroge l'API.
    public function check_order($order) {
      $id = $order->get_meta('_cv_payment_id'); if (!$id) return;
      $res = $this->call('GET', '/api/v1/payments/' . rawurlencode($id)); if (is_wp_error($res) || $res['code'] !== 200) return;
      $st = $res['data']['status'] ?? '';
      if ($st === 'confirmed') {
        if (($res['data']['mode'] ?? '') === 'live') $order->payment_complete($id);
        else { $order->add_order_note('Coinvera : paiement de TEST confirmé (commande non marquée payée).'); $order->update_status('on-hold'); }
      } elseif (in_array($st, ['failed', 'expired'], true)) $order->update_status('failed', 'Coinvera : paiement ' . $st . '.');
      elseif ($order->get_date_created() && time() - $order->get_date_created()->getTimestamp() > DAY_IN_SECONDS) $order->update_status('cancelled', 'Coinvera : paiement non reçu sous 24 h.');
    }
  }
  add_filter('woocommerce_payment_gateways', function ($g) { $g[] = 'WC_Gateway_Coinvera'; return $g; });
  add_action('cv_check_orders', function () {
    $gw = new WC_Gateway_Coinvera();
    foreach (wc_get_orders(['payment_method' => 'coinvera', 'status' => ['pending', 'on-hold'], 'limit' => 50, 'date_created' => '>' . (time() - 3 * DAY_IN_SECONDS)]) as $o) $gw->check_order($o);
  });
  add_action('woocommerce_thankyou_coinvera', function ($id) { $o = wc_get_order($id); if ($o && $o->has_status(['pending', 'on-hold'])) (new WC_Gateway_Coinvera())->check_order($o); });
});

// Mises a jour : interroge l'API Coinvera pour la derniere version publiee.
add_filter('pre_set_site_transient_update_plugins', function ($t) {
  if (empty($t->checked)) return $t;
  $o = get_option('woocommerce_coinvera_settings', []); $r = wp_remote_get(rtrim($o['api_base'] ?? 'https://coinvera.com', '/') . '/api/license/update', ['timeout' => 10]);
  if (is_wp_error($r)) return $t; $d = json_decode(wp_remote_retrieve_body($r), true);
  if (!empty($d['version']) && version_compare($d['version'], CV_VERSION, '>')) $t->response[CV_SLUG] = (object) ['slug' => 'coinvera-crypto-gateway', 'plugin' => CV_SLUG, 'new_version' => $d['version'], 'package' => $d['download_url']];
  return $t;
});
// Desactivation de la licence quand le plugin est desactive : libere l'emplacement du site.
register_deactivation_hook(__FILE__, function () {
  $o = get_option('woocommerce_coinvera_settings', []); if (empty($o['license_key'])) return;
  wp_remote_post(rtrim($o['api_base'] ?? 'https://coinvera.com', '/') . '/api/license/deactivate', ['timeout' => 10, 'headers' => ['Content-Type' => 'application/json'], 'body' => wp_json_encode(['licenseKey' => $o['license_key'], 'siteUrl' => home_url()])]);
});
